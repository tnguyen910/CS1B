#include "hw02.hpp"

void CoffeeShop::showCupCount() {

    std::cout << "Small Sales: " << coffeeSold[0] << std::endl;
    std::cout << "Medium Sales: " << coffeeSold[1] << std::endl;
    std::cout << "Large Sales: " << coffeeSold[2] << std::endl;
}
